<div align="center">

# codex-provider-sync

### 切换 provider 后，让 Codex 历史会话重新可见

[![CI](https://github.com/Dailin521/codex-provider-sync/actions/workflows/ci.yml/badge.svg)](https://github.com/Dailin521/codex-provider-sync/actions/workflows/ci.yml)
[![Platform](https://img.shields.io/badge/platform-Windows-lightgrey.svg)](https://github.com/Dailin521/codex-provider-sync)
[![Node](https://img.shields.io/badge/node-16%2B-brightgreen.svg)](https://nodejs.org/)
[![License](https://img.shields.io/badge/license-MIT-blue.svg)](LICENSE)

中文 | [English](docs/README_EN.md)

</div>

## 解决什么问题

Codex 切换 `model_provider` 后，旧会话可能在 Desktop 或 `/resume` 里不可见。原因通常不是会话文件丢了，而是 rollout 文件、SQLite 线程表、项目路径缓存里的 provider / 可见性 metadata 不一致。

本工具同步这些位置：

- `~/.codex/sessions`
- `~/.codex/archived_sessions`
- `~/.codex/state_5.sqlite`
- `.codex-global-state.json` 中的项目根路径缓存

## 快速使用

Windows 用户优先下载 Release 里的 `CodexProviderSync.exe`：

1. 打开 `CodexProviderSync.exe`
2. 点击“刷新”
3. 选择目标 Provider
4. 点击“立即同步”

Windows GUI 每天首次启动会在后台检查一次本项目最新的稳定版 GitHub Release，也可以随时点击右侧的“检查更新”手动重试。自动和手动版本查询最多等待 10 秒；网络或代理异常不会阻止软件启动，自动检查失败也不会弹窗。确认更新后，程序会下载 `CodexProviderSync.exe`、校验同版本发布的 SHA-256 文件、退出并由临时更新器再次校验后原子替换原 EXE，再自动重启。更新器临时目录会在后续启动时自动清理。若 EXE 所在目录没有写入权限，更新不会覆盖旧版本，程序会尽力重启旧版，并在提示中保留下载路径供手动安装。

macOS 用户可使用 Avalonia 桌面版，构建说明见 [README_MAC_GUI_ZH.md](docs/README_MAC_GUI_ZH.md)。

其它环境使用 CLI：

```bash
npm install -g git+https://github.com/Dailin521/codex-provider-sync.git
codex-provider sync
```

CLI 需要 Node.js `16+`。Node 24+ 会优先使用内置 `node:sqlite`；旧版 Node 会使用可选依赖 `better-sqlite3`。

更多 CLI 常用命令：

```bash
codex-provider status
codex-provider sync
codex-provider sync --provider openai
codex-provider switch apigather
codex-provider switch apigather --model "MiniMax-M3"     # 同时改顶层 model
codex-provider switch apigather --keep-root-model        # 只改 model_provider，不动顶层 model
codex-provider restore C:\Users\you\.codex\backups_state\provider-sync\<timestamp>
codex-provider prune-backups --keep 5
```

命令含义：

- `status`：只检查当前 provider、rollout、SQLite、项目可见性诊断。
- `sync`：不切换登录状态，只把历史会话 metadata 同步到当前 provider。
- `switch <provider-id>`：修改 `config.toml` 根级 `model_provider` 并默认把顶层 `model` 同步到新 provider section 里的 `model`（可用 `--keep-root-model` 关闭，或用 `--model <NAME>` 显式覆盖），然后执行同步。
- `restore <backup-dir>`：从备份恢复，支持 `--no-config`、`--no-db`、`--no-sessions`。
- `prune-backups --keep <n>`：只清理本工具创建的旧备份。

备注：频繁切换时，建议使用统一的 6 字符 ASCII provider ID，例如将逻辑名称 `provider_a` 配置为 `prov_a`。内置的 `openai` ID 正好是 6 个字符，因此统一为 6 字符相对最通用。会话文件很多或体积很大时，不同长度的 ID 需要重写整个 rollout，可能产生巨量磁盘写入；JSON 编码后的字节长度相同且无需同步 model 字段时可原地替换，其他情况仍自动回退到完整安全重写。

## 能力边界

本工具只修复“历史会话可见性”相关 metadata，不修改会话内容。

- 不处理登录、认证、`auth.json` 或第三方切号工具。
- 不修改消息历史、会话标题、对话内容。
- 不修改 `updated_at`，不通过改变历史排序来修复 Desktop 显示。
- 不把旧会话里的 `encrypted_content` 重新加密到另一个 provider / account。
- 含 `encrypted_content` 的旧会话跨 provider/account 后，通常只能恢复列表可见性，继续对话或 compact 仍可能报 `invalid_encrypted_content`。

## Codex Desktop 最近 50 条限制

目前 Codex Desktop 的 Recent/项目侧会话列表存在一个上游显示限制：前端首屏只拉取最近 `50` 条会话。

影响：

- CLI `/resume` 能看到的旧会话，Desktop 项目侧可能仍显示“暂无对话”。
- 旧项目会话如果排在全局最近 50 条之后，Desktop 首屏可能不会展示。
- `codex-provider-sync status` / GUI Refresh 会显示 `first page 0/50`、`ranks 64-77` 这类诊断，帮助判断是不是这个问题。

本工具不会通过修改 `updated_at` 或文件时间把旧会话强行挤进前 50。这个问题应由 Codex Desktop 上游改成按项目分页加载，或提高/开放首屏加载数量。

## 安全与排障

每次 `sync` / `switch` 前都会备份到：

```text
~/.codex/backups_state/provider-sync/<timestamp>
```

注意：

- 如果 `state_5.sqlite` 被占用，关闭 Codex / Codex App / app-server 后重试。
- 如果 `state_5.sqlite` 损坏，工具会提示 malformed/unreadable 并停止同步。
- 如果活跃会话锁住 rollout 文件，工具会跳过该文件并继续处理其它历史会话。
- 常规执行日志按天写入 `%AppData%\codex-provider-sync\logs\execution-YYYY-MM-DD.log`，默认保留最近 30 天，也可在 GUI 中点击“打开日志目录”。
- 如果 EXE 双击无反应，先确认已解压，再查看 `%AppData%\codex-provider-sync\startup-error.log` 和当天执行日志，或在 PowerShell 里运行 `./CodexProviderSync.exe`。
- 内置更新只检查稳定版 GitHub Release，且需要用户在 GUI 中确认；项目目前未做 Windows 代码签名，SHA-256 校验可检测下载损坏，但不能替代代码签名。

Windows GUI 说明见 [README_GUI_ZH.md](docs/README_GUI_ZH.md)，macOS GUI 说明见 [README_MAC_GUI_ZH.md](docs/README_MAC_GUI_ZH.md)。AI / Agent 说明见 [AGENTS.md](AGENTS.md)。

## 开发

```bash
git clone https://github.com/Dailin521/codex-provider-sync.git
cd codex-provider-sync
npm test
dotnet test desktop/CodexProviderSync.Core.Tests/CodexProviderSync.Core.Tests.csproj
pwsh ./scripts/publish-gui.ps1
./scripts/publish-gui-macos.sh
```

## License

MIT
